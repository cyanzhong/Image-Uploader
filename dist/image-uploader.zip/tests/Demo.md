## Demo

This file is for testing purpose only.

Here are some local images:

![Hello](./assets/IMG_1.JPG)

![](assets/IMG_2.JPG)

Here is an image path with Chinese characters:

![中文](assets/%E4%B8%AD%E6%96%87%E6%B5%8B%E8%AF%95.jpg)

The same one without URL encoding:

![中文](assets/中文测试.jpg)

Here is a remoe image, which should not be included:

![Bazinga](https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png)