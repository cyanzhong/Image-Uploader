const root = $file.rootPath + "/ImageUploader";
const backup = root + "/Backup";
const cache = root + "/Cache";
const thumbnails = cache + "/Thumbnails";

module.exports = {
  root,
  backup,
  cache,
  thumbnails,
}