module.exports = {
  hairline: 1.0 / $device.info.screen.scale,
  toolbarHeight: 44,
  spacingOfCells: 5,
  footerHeight: 32,
  footerFontSize: 13,
}