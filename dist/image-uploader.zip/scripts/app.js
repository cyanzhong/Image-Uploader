module.exports = {
  init: require("./ui/main/index")
}